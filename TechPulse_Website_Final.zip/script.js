$(function () {
  const $storyItems = $(".story-item");
  let activeFilter = "all";

  function filterStories() {
    const query = $("#storySearch").val().trim().toLowerCase();
    let visibleCount = 0;

    $storyItems.each(function () {
      const $item = $(this);
      const category = String($item.data("category"));
      const title = String($item.data("title")).toLowerCase();
      const content = $item.find(".story-body p").text().toLowerCase();
      const matchesCategory = activeFilter === "all" || category === activeFilter;
      const matchesSearch = !query || title.includes(query) || content.includes(query);
      const shouldShow = matchesCategory && matchesSearch;

      $item.toggleClass("d-none", !shouldShow);
      if (shouldShow) visibleCount += 1;
    });

    $("#emptyState").toggleClass("d-none", visibleCount !== 0);
  }

  $(".category-btn").on("click", function () {
    $(".category-btn").removeClass("active");
    $(this).addClass("active");
    activeFilter = String($(this).data("filter"));
    filterStories();
  });

  $("#storySearch").on("input", filterStories);

  $("#newsletterForm").on("submit", function (event) {
    event.preventDefault();
    const email = $("#emailInput").val().trim();
    if (!email) return;

    $("#formMessage")
      .text("Thanks! This demo form works locally, but no email was sent.")
      .addClass("success-message");
    this.reset();
  });

  $(window).on("scroll", function () {
    $("#backToTop").toggleClass("visible", $(this).scrollTop() > 350);
  });

  $("#backToTop").on("click", function () {
    $("html, body").animate({ scrollTop: 0 }, 450);
  });

  $(".navbar-nav .nav-link").on("click", function () {
    const nav = document.getElementById("mainNav");
    if (nav && nav.classList.contains("show")) {
      bootstrap.Collapse.getOrCreateInstance(nav).hide();
    }
  });

  $("#year").text(new Date().getFullYear());

  // Keep the current navigation item in sync with the visible section.
  const sections = $("main section[id]");
  $(window).on("scroll", function () {
    let current = "home";
    sections.each(function () {
      if ($(window).scrollTop() >= $(this).offset().top - 140) current = this.id;
    });
    $(".navbar-nav .nav-link").removeClass("active");
    $('.navbar-nav .nav-link[href="#' + current + '"]').addClass("active");
  });
});
