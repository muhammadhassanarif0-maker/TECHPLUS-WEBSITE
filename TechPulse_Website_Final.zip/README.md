# TechPulse — Technology Website

A responsive technology editorial website made with HTML5, CSS3, Bootstrap 5, JavaScript, jQuery, and Font Awesome.

## Files
- `index.html` — page structure and content
- `style.css` — responsive dark theme and custom visuals
- `script.js` — story filtering/search, newsletter demo interaction, active navigation, and back-to-top button

## Run locally
Open `index.html` in a browser. Internet is required for Bootstrap, jQuery, Font Awesome, and Google Fonts CDN assets.

## Deploy to Netlify
1. Create a public GitHub repository, for example `techpulse-website`.
2. Upload `index.html`, `style.css`, `script.js`, and `README.md` to the repository root.
3. In Netlify, choose **Add new site → Import an existing project**, connect GitHub, and select the repository.
4. Set the publish directory to `.` (root); no build command is required.
5. Deploy, open the provided URL, and test the page on desktop and mobile.

You can also use Netlify's manual deploy by dragging the project folder (or a ZIP containing the site files) into its deploy interface.

## Notes
- The newsletter form is a front-end demo only; it does not store addresses or send emails.
- Story cards are sample editorial content for the project, not current news reports.
- External CDN assets require an internet connection.
